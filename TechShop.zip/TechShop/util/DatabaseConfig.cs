﻿namespace TechShop.util
{
    public static class DatabaseConfig
    {
        // Update your connection string here
        public static string ConnectionString => "Server=SARAVANAPRIYA-2;Database=TechShop;Trusted_Connection=True;TrustServerCertificate=True;";
    }
}
