using assignment_2.main;

namespace assignment_2
{
    class Program
    {
        static void Main(string[] args)
        {
            MainModule.Run();
        }
    }
}
